# QISH BOT ❤️

## Windows setup
1. Open Telegram and talk to @BotFather. Send `/newbot` and follow the prompts. Copy the token. Keep it private.
2. Install Python 3.10 or later.
3. Open PowerShell in this folder and run `py -m pip install -r requirements.txt`.
4. Copy `.env.example` to `.env`. Paste your token into `TELEGRAM_BOT_TOKEN`.
5. Optional: add an OpenAI API key to `OPENAI_API_KEY` for AI chat. API usage may incur charges.
6. Run `py bot.py`.
7. Open your bot in Telegram, send `/myid`, and copy the numeric ID into `ALLOWED_USER_ID` in `.env` to restrict access to that Telegram account. Restart the bot.

## Personalize
Edit the `LOVE`, `LETTERS`, `QUESTIONS` and surprise message arrays in `bot.py`. Add memories with `/memory Your special memory`.

## Notes
The bot runs while the Python process is running. SQLite memories are stored locally in `qish.db`. The AI chat sends her messages to the configured AI provider. Tell her about this before she uses AI chat. Do not share `.env`, API keys or the database publicly.
