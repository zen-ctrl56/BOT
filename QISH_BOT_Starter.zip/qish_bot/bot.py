import os
import random
import sqlite3
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ApplicationBuilder, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

load_dotenv()
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
ALLOWED = os.getenv('ALLOWED_USER_ID', '').strip()
DB = Path(__file__).with_name('qish.db')
LOVE = ['You are my favorite notification. ❤️', 'If today feels heavy, remember you are loved. 🌷', 'Every little moment with you matters to me. 💗']
LETTERS = ['Dear Qish, I made this tiny universe because you deserve little reasons to smile. Love, Zen. ❤️', 'Some days are ordinary, but knowing you makes them special. 💌']
QUESTIONS = [('What is the secret password to this little universe?', ['Qish', 'Pizza', 'Moon'], 0), ('What matters most here?', ['Winning', 'Being kind', 'Speed'], 1)]

def db():
    con = sqlite3.connect(DB)
    con.execute('CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, joined TEXT)')
    con.execute('CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, text TEXT, created TEXT)')
    con.commit()
    return con

def menu():
    buttons = [[InlineKeyboardButton('❤️ Love Center', callback_data='love'), InlineKeyboardButton('🤖 AI Chat', callback_data='ai')], [InlineKeyboardButton('🎮 Mini Games', callback_data='games'), InlineKeyboardButton('🎁 Surprise', callback_data='surprise')], [InlineKeyboardButton('📖 Our Story', callback_data='story'), InlineKeyboardButton('💌 Letters', callback_data='letters')], [InlineKeyboardButton('⚙️ Help', callback_data='help')]]
    return InlineKeyboardMarkup(buttons)

def back():
    return InlineKeyboardMarkup([[InlineKeyboardButton('🏠 Main Menu', callback_data='menu')]])

async def authorized(update):
    uid = update.effective_user.id
    if ALLOWED and str(uid) != ALLOWED:
        if update.callback_query:
            await update.callback_query.answer('This bot is private.', show_alert=True)
        elif update.message:
            await update.message.reply_text('This is a private bot. 💗')
        return False
    return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await authorized(update): return
    with db() as con:
        con.execute('INSERT OR IGNORE INTO users VALUES (?, ?)', (update.effective_user.id, datetime.now().isoformat()))
    await update.message.reply_text('Hello, Qish! ❤️\nWelcome to your own little universe. Someone made this just for you. ✨', reply_markup=menu())

async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f'Your Telegram user ID: {update.effective_user.id}')

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await authorized(update): return
    q = update.callback_query
    await q.answer()
    action = q.data
    if action == 'menu':
        await q.edit_message_text('Your little universe 💗\nWhere shall we go?', reply_markup=menu())
    elif action == 'love':
        await q.edit_message_text(random.choice(LOVE), reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('💞 Another', callback_data='love')], [InlineKeyboardButton('🏠 Menu', callback_data='menu')]]))
    elif action == 'ai':
        context.user_data['chatting'] = True
        await q.edit_message_text('🤖 AI Companion\nSend me a message! Type /menu to leave AI chat.\n(An AI assistant, not Zen.)', reply_markup=back())
    elif action == 'games':
        i = random.randrange(len(QUESTIONS))
        context.user_data['question'] = i
        question, options, correct = QUESTIONS[i]
        await q.edit_message_text('🎮 ' + question, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(o, callback_data=f'answer:{i}:{j}')] for j, o in enumerate(options)] + [[InlineKeyboardButton('🏠 Menu', callback_data='menu')]]))
    elif action.startswith('answer:'):
        _, i, choice = action.split(':')
        i, choice = int(i), int(choice)
        await q.edit_message_text('🎉 Correct! You know this universe well. ❤️' if choice == QUESTIONS[i][2] else 'Hehe, try another one! 💗', reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('🎮 Play Again', callback_data='games')], [InlineKeyboardButton('🏠 Menu', callback_data='menu')]]))
    elif action == 'surprise':
        await q.edit_message_text(random.choice(['🎁 Surprise! You are officially entitled to one giant virtual hug. 🫂', '🌟 Secret unlocked: You are the star of this tiny universe.', '💐 A little bouquet, just for you.']), reply_markup=back())
    elif action == 'story':
        with db() as con:
            memories = con.execute('SELECT text, created FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 10', (update.effective_user.id,)).fetchall()
        msg = '📖 Our Story\n\n' + ('\n'.join('• ' + m[0] for m in memories) if memories else 'No memories saved yet. Add one using /memory followed by your memory.')
        await q.edit_message_text(msg[:4000], reply_markup=back())
    elif action == 'letters':
        await q.edit_message_text(random.choice(LETTERS), reply_markup=back())
    elif action == 'help':
        await q.edit_message_text('Commands:\n/start — welcome\n/menu — main menu\n/myid — show your Telegram ID\n/memory your memory — save a memory\n/stop — leave AI chat\n\nAI chat requires OPENAI_API_KEY in .env.', reply_markup=back())

async def show_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await authorized(update): return
    context.user_data['chatting'] = False
    await update.message.reply_text('🏠 Main menu', reply_markup=menu())

async def memory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await authorized(update): return
    content = ' '.join(context.args).strip()
    if not content:
        await update.message.reply_text('Use: /memory Our first adventure together')
        return
    with db() as con:
        con.execute('INSERT INTO memories (user_id, text, created) VALUES (?, ?, ?)', (update.effective_user.id, content[:1000], datetime.now().isoformat()))
    await update.message.reply_text('Saved to Our Story. 📖❤️')

async def chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await authorized(update): return
    if not context.user_data.get('chatting'):
        await update.message.reply_text('Choose a little adventure:', reply_markup=menu())
        return
    if not os.getenv('OPENAI_API_KEY'):
        await update.message.reply_text('AI chat is not configured yet. The other features still work!')
        return
    try:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        history = context.user_data.setdefault('history', [])
        history.append({'role': 'user', 'content': update.message.text[:2000]})
        history[:] = history[-12:]
        response = await client.chat.completions.create(model=os.getenv('OPENAI_MODEL', 'gpt-4.1-mini'), messages=[{'role': 'system', 'content': 'You are Qish Bot, a clearly identified AI companion made as a sweet gift for Qish. Be warm, playful, kind, concise, and respectful. Do not claim to be Zen or a human. Never pressure Qish emotionally. Do not claim to know private relationship facts not provided.'}, *history])
        reply = response.choices[0].message.content or '💗'
        history.append({'role': 'assistant', 'content': reply})
        await update.message.reply_text(reply[:4000])
    except Exception:
        await update.message.reply_text('My AI connection is taking a little nap. Try again later. 💗')

if __name__ == '__main__':
    if not TOKEN or TOKEN == 'PASTE_YOUR_BOTFATHER_TOKEN':
        raise SystemExit('Set TELEGRAM_BOT_TOKEN in your .env file first.')
    db().close()
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('myid', myid))
    app.add_handler(CommandHandler(['menu', 'stop'], show_menu))
    app.add_handler(CommandHandler('memory', memory))
    app.add_handler(CallbackQueryHandler(buttons))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat))
    print('QISH BOT is running...')
    app.run_polling()
